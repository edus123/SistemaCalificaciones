package Main;
import vistas.MenuTemplate;

public class Main {

	public static void main(String[] args) throws Exception {
	  MenuTemplate menu = new MenuTemplate();

	  
	  
	  menu.iniciarMenu();
	  
	  
	 
   }
}
