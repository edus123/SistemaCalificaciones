package modelos;

public enum MateriaEnum {
	MATEMATICAS,
	LENGUAJE,
	CIENCIA,
	HISTORIA,;

}
